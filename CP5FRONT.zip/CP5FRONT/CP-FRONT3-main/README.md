📰 Portal de Notícias

Um portal de notícias moderno e dinâmico, desenvolvido para oferecer ao usuário uma experiência simples e intuitiva na leitura de artigos e acompanhamento de informações em tempo real.

📌 Funcionalidades

Listagem de notícias organizadas por categoria (Política, Esportes, Tecnologia, Entretenimento, etc.).

Busca de notícias por título ou palavra-chave.

Página detalhada de cada notícia.

Sistema de autenticação para jornalistas e administradores.

Painel administrativo para publicação, edição e exclusão de notícias.

Interface responsiva para dispositivos móveis e desktop.


Rafael Malaguti - 561830
Nickolas Davi - 564105
Samara Vilela - 566133
